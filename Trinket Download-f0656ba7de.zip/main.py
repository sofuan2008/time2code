# Currency converter program

# -------------------------
# Subprograms
# -------------------------
def exchange(gbp, currency):
  if currency  == "USD":
    money = gbp * 1.3
    return money
    
  elif currency == "EURO":
    money = gbp * 1.1
    return money
    
  elif currency == "YUAN":
    money =  gbp * 8.92
    return money
    
  elif currency == " YEN":
    money= gbp * 1380.44
    return money
  
  else:
    print ("currency currently not avaliavle")
  
# -------------------------
# Main program
# -------------------------
gbp = float(input("Enter the amount of cash you want to exchange :£ "))
currency = input(" Enter the currency you want to exchange to [USD | EURO | YUAN | YEN :  ")
money = exchange(gbp, currency)
print(gbp, "GBP =", money, currency)
