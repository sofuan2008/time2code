# Periodic table program

# -------------------------
# Subprograms
# -------------------------
def periodic_table(element):
  match element:
    case  "Li" | "Lithium":
      symbol = "Li"
      name = "Lithium"
      atomic_weight = 6.94
      group = "Alkali Metals"
      return symbol, name, atomic_weight, group
      
    case "Na" | "Sodium":
      symbol = "Na"
      name =  "Sodium"
      atomic_weight = 22.99
      group = "Alkali Metals"
      return symbol, name, atomic_weight, group
      
    case "K" | "Potassium":
      symbol = "K"
      name =  "Sodium"
      atomic_weight = 39.098
      group = "Alkali Metals"
      return symbol, name, atomic_weight, group
      
    case "F" | "Flourine":
      symbol = "F"
      name = "Flourine"
      atomic_weight = 18.998
      group = "Halogens"
      return symbol, name, atomic_weight, group
      
    case "Cl" | "Chlorine":
      symbol = "Cl"
      name = "Chlorine"
      atomic_weight = 35.45
      group = "Halogens"
      return symbol, name, atomic_weight, group
      
    case "Br" | "Bromine":
      symbol = "Br"
      name = "Bromine"
      atomic_weight = 79.904
      group = "Halogens"
      return symbol, name, atomic_weight, group
  


# -------------------------
# Main program
# -------------------------
element = input ("Enter name of element: ") 
symbol, name, atomic_weight, group = periodic_table(element)
print (" Symbol: ", symbol ," \n Name: " ,name, " \n Atomic weight: ",atomic_weight," \n Group: ", group)